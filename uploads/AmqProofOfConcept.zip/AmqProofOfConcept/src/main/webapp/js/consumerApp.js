/**
 * Consumer App
 */
var app = angular.module("consumerApp", []);
